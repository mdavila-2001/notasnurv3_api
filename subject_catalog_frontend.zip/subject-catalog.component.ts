import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

interface Semester {
  id: number;
  name: string;
}

interface Teacher {
  id: number;
  fullName: string;
  email: string;
}

interface Subject {
  id: number;
  name: string;
  code: string;
  semesterId: number;
  semesterName: string;
  teacherId: number;
  teacherName: string;
}

@Component({
  selector: 'app-subject-catalog',
  templateUrl: './subject-catalog.component.html',
  styleUrls: ['./subject-catalog.component.css']
})
export class SubjectCatalogComponent implements OnInit {
  subjectForm!: FormGroup;

  semesters: Semester[] = [
    { id: 1, name: 'First Semester' },
    { id: 2, name: 'Second Semester' }
  ];

  teachers: Teacher[] = [
    { id: 1, fullName: 'Carlos Docente', email: 'cdocente@nur.edu.bo' }
  ];

  subjects: Subject[] = [];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.subjectForm = this.fb.group({
      name: ['', Validators.required],
      code: ['', Validators.required],
      semesterId: [null, Validators.required],
      teacherId: [null, Validators.required]
    });
  }

  createSubject(): void {
    if (this.subjectForm.invalid) return;

    const semester = this.semesters.find(s => s.id === this.subjectForm.value.semesterId);
    const teacher = this.teachers.find(t => t.id === this.subjectForm.value.teacherId);

    this.subjects.push({
      id: this.subjects.length + 1,
      name: this.subjectForm.value.name,
      code: this.subjectForm.value.code,
      semesterId: this.subjectForm.value.semesterId,
      semesterName: semester?.name || '',
      teacherId: this.subjectForm.value.teacherId,
      teacherName: teacher?.fullName || ''
    });

    this.subjectForm.reset();
  }
}
